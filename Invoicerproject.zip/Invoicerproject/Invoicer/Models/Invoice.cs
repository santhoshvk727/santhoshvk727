﻿namespace Invoicer.Models
{
    public class Invoice
    {
        public int SId { get; set; }
        public string StudentFirstName { get; set; }

        public string StudentLastName { get; set; }

        public int CourseId { get; set; }

        public string CourseName { get; set; }

        public string CourseDuration { get; set; }

        public int CourseFees { get; set; }

        public string Paymenttype {  get; set; }

        public int PaymentAmount {  get; set; }

        public DateTime DueDate { get; set; }

        public DateTime PaymentDate {  get; set; }
    }
}
