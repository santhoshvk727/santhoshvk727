﻿using Invoicer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;


namespace Invoicer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private IConfiguration Configuration;

        public InvoiceController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        [HttpGet]
        [Route("GetNotes")]
        public IActionResult GetNotes()
        {
            List<Invoice> invoices = new List<Invoice>();
            string query = "SELECT  s.SId, s.StudentFirstName, s.StudentLastName, c.CourseId, c.CourseName, c.CourseDuration,  c.CourseFees,  p.Paymenttype,  p.PaymentAmount,  p.DueDate,  p.PaymentDate FROM   Student s INNER JOIN  Course c ON s.CourseId = c.CourseId INNER JOIN   Payment p ON s.SId = p.Sid";
            DataTable table = new DataTable();
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            SqlDataReader myReader;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand mycommand = new SqlCommand(query, connection);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(mycommand);
                if (dataAdapter is not null)
                {
                    dataAdapter.Fill(table);
                    foreach (DataRow dr in table.Rows)
                    {
                        Invoice details = new Invoice();


                        details.SId = Convert.ToInt32(dr["SId"]);
                        details.StudentFirstName = Convert.ToString(dr["StudentFirstName"]);
                        details.StudentLastName = Convert.ToString(dr["StudentLastName"]);
                        details.CourseId = Convert.ToInt32(dr["CourseId"]);
                        details.CourseName = Convert.ToString(dr["CourseName"]);
                        details.CourseDuration = Convert.ToString(dr["CourseDuration"]);
                        details.CourseFees = Convert.ToInt32(dr["CourseFees"]);
                        details.Paymenttype = Convert.ToString(dr["Paymenttype"]);
                        details.PaymentAmount = Convert.ToInt32(dr["PaymentAmount"]);
                        details.DueDate = Convert.ToDateTime(dr["DueDate"]);
                        details.PaymentDate = Convert.ToDateTime(dr["PaymentDate"]);




                        invoices.Add(details);
                    }
                }
            }
            return Ok(invoices);

        }
    }
}
